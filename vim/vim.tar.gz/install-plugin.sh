#!/bin/bash

vim +PluginInstall +qall
