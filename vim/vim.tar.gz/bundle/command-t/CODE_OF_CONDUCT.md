# Cod of Conduct

![](https://raw.githubusercontent.com/wincent/command-t/media/cod-of-conduct.png)

## TL;DR

> Be nice!

## Project ~~Cod~~ Code of Conduct

This is just a personal side project of mine, so I'd feel a bit ridiculous putting something extensive like [The Contributor Covenant](https://www.contributor-covenant.org/) or the [Facebook Open Source Code of Conduct](https://code.fb.com/codeofconduct/) on it. Nevertheless, I want this to be a safe place where all people can participate — whether that be reporting bugs, making feature requests, asking questions, or submitting pull requests — and know that they'll be treated with respect and civility. As maintainer, I undertake to make this a welcoming and inclusive place, and I ask that all participants do the same.

Please [email me](mailto:greg@hurrell.net) or open an issue if you'd like to draw anything problematic to my attention.
