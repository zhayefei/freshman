package main

func main() {
	notafunc()
	println("vim-go")
}
