#vim

bdep's vimrc
